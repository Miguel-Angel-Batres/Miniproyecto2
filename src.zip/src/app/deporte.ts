export interface Deporte {
    nombre: string;
    bio: string;
    img: string;
    horario: string;
    costo: number;
}
