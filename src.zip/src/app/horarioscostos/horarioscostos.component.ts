import { Component } from '@angular/core';

@Component({
  selector: 'app-horarioscostos',
  imports: [],
  templateUrl: './horarioscostos.component.html',
  styleUrl: './horarioscostos.component.css'
})
export class HorarioscostosComponent {

}
